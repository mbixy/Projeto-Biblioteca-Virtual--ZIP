document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form[role="search"]');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        searchBooks();
    });
});

function searchBooks() {
    const searchInput = document.querySelector('input[type="search"]').value.toLowerCase();
    const categoriaFiltro = document.getElementById('categoriaFiltro').value.toLowerCase();
    const livros = document.querySelectorAll('.livro');

    livros.forEach(livro => {
        const titulo = livro.querySelector('.titulo').innerText.toLowerCase();
        const autor = livro.querySelector('.autor').innerText.toLowerCase();

        if ((titulo.includes(searchInput) || autor.includes(searchInput)) &&
            (categoriaFiltro === '' || livro.closest('.livros').getAttribute('data-categoria') === categoriaFiltro)) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
}


////////////

function adicionarFavorito(livroId) {
    const userId = getUserId(); // Supondo que você tenha uma forma de obter o ID do usuário logado

    fetch('/api/adicionarFavorito', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, livroId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const messageDiv = document.getElementById('message');
            messageDiv.textContent = 'Livro favoritado com sucesso!';
            messageDiv.style.display = 'block';

            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        } else {
            console.error('Erro ao favoritar o livro');
        }
    })
    .catch(error => console.error('Erro ao favoritar o livro:', error));
}

function getUserId() {
    // Esta função deve retornar o ID do usuário logado
    // Pode ser obtido de um cookie, local storage, ou sessão
    return 1; // Exemplo estático
}





const express = require('express');
const mysql = require('mysql');
const app = express();

app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'sua_senha',
    database: 'sua_base_de_dados'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao banco de dados.');
});

app.post('/api/adicionarFavorito', (req, res) => {
    const { userId, livroId } = req.body;
    let sql = 'INSERT INTO favoritos (user_id, livro_id) VALUES (?, ?)';
    db.query(sql, [userId, livroId], (err, result) => {
        if (err) {
            console.error('Erro ao adicionar favorito:', err);
            return res.json({ success: false });
        }
        res.json({ success: true });
    });
});

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});

