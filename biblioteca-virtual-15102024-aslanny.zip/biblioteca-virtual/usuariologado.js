document.getElementById('searchFormUsuLogado').addEventListener('submit', function(event) {
    event.preventDefault();
    searchBooks();
});

function searchBooks() {
    const searchInput = document.getElementById('searchInputUsuLogado').value.toLowerCase();
    const categoriaFiltro = document.getElementById('categoriaFiltroUsuLogado').value.toLowerCase();
    const livros = document.querySelectorAll('.livroUsuLogado');

    livros.forEach(livro => {
        const titulo = livro.querySelector('.tituloUsuLogado').innerText.toLowerCase();
        const autor = livro.querySelector('.autorUsuLogado').innerText.toLowerCase();

        if ((titulo.includes(searchInput) || autor.includes(searchInput)) &&
            (categoriaFiltro === '' || livro.closest('.livrosUsuLogado').getAttribute('data-categoria') === categoriaFiltro)) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
}
