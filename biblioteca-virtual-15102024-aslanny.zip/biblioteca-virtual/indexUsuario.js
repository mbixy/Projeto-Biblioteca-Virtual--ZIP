document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form[role="search"]');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        searchBooks();
    });
});

function searchBooks() {
    const searchInput = document.querySelector('input[type="search"]').value.toLowerCase();
    const categoriaFiltro = document.getElementById('categoriaFiltro').value.toLowerCase();
    const livros = document.querySelectorAll('.livro');

    livros.forEach(livro => {
        const titulo = livro.querySelector('.titulo').innerText.toLowerCase();
        const autor = livro.querySelector('.autor').innerText.toLowerCase();

        if ((titulo.includes(searchInput) || autor.includes(searchInput)) &&
            (categoriaFiltro === '' || livro.closest('.livros').getAttribute('data-categoria') === categoriaFiltro)) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
}
