
document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
//cadastra usuário
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const idade = document.getElementById('idade').value;

    // Cria o objeto com os dados do usuário
    const usuario = {
        nome: nome,
        email: email,
        senha: senha,
        idade: idade,
        dataCadastro: new Date().toISOString().split('T')[0], // Formata a data no formato YYYY-MM-DD
        statusCadastro: 'ativo'
    };

    try {
        const response = await fetch('http://localhost:3002/usuario', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usuario)
        });

        const result = await response.json();
        if (response.ok) {
            alert('Usuário cadastrado com sucesso!');
            document.getElementById('message').innerText = 'Usuário cadastrado com sucesso!';
        } else {
            alert('Erro ao cadastrar usuário.');
            document.getElementById('message').innerText = result.message || 'Erro ao cadastrar usuário.';
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao se conectar com o servidor.');
        document.getElementById('message').innerText = 'Erro ao se conectar com o servidor.';
    }
});

//Sistema de pequisa dos livros (HTML)


document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const livros = document.querySelectorAll('.livro');
    livros.forEach(function(livro) {
        const titulo = livro.querySelector('.titulo').innerText.toLowerCase();
        const autor = livro.querySelector('.autor').innerText.toLowerCase();
        if (titulo.includes(searchInput) || autor.includes(searchInput)) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
});