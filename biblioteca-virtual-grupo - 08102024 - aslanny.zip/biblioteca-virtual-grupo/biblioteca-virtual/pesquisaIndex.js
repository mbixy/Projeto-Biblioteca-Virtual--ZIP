document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const searchInput = document.getElementById('searchInput').value.toLowerCase().trim();
    const livros = document.querySelectorAll('.livro');
    
    let results = []; // Para armazenar os livros encontrados

    livros.forEach(function(livro) {
        const titulo = livro.querySelector('.titulo').innerText.toLowerCase();
        const autor = livro.querySelector('.autor').innerText.toLowerCase();
        if (titulo.includes(searchInput) || autor.includes(searchInput)) {
            results.push(livro);
        } else {
            livro.style.display = 'none'; // Esconde todos os livros
        }
    });
    
    if (results.length > 0) {
        livros.forEach(function(livro) {
            livro.style.display = 'none'; // Certifica que todos os livros estão escondidos
        });
        results.forEach(function(livro) {
            livro.style.display = 'block'; // Exibe apenas os livros encontrados
        });
    } else {
        alert('Livro não encontrado.');
    }
});
