//Sistema de pequisa dos livros (HTML)


document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const livros = document.querySelectorAll('#livrosList li');

    livros.forEach(function(livro) {
        const titulo = livro.querySelector('h3').textContent.toLowerCase();
        const autor = livro.querySelector('h4').textContent.toLowerCase();
        const categoria = livro.querySelector('p').textContent.toLowerCase();

        if (titulo.includes(searchTerm) || autor.includes(searchTerm) || categoria.includes(searchTerm)) {
            livro.style.display = '';
        } else {
            livro.style.display = 'none';
        }
    });
});




// Função para verificar se o usuário está logado
function checkLogin() {
    // Aqui você deve adicionar a lógica para verificar se o usuário está logado
    const verificarUsuario = true; // Alterar para a lógica real
    if (!verificarUsuario) {
        window.location.href = 'login.html'; // Redirecionar para a página de login se não estiver logado
    }
}

//// ADICIONA AOS FAVORITOS E REGISTRA NO BANCO DE DADOS

function addFavorite(button) {
    // Obtem o título do livro do elemento <h2> que está próximo ao botão
    const bookTitle = button.closest('div').querySelector('h2').innerText;

    // Mostrar a mensagem de favorito adicionado
    alert(bookTitle + " adicionado aos favoritos!");

    // Adicionar a lógica para armazenar os favoritos no banco de dados
    fetch('/addFavorite', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: bookTitle })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}






// Função para mostrar ou esconder opções
function toggleOptions() {
    const options = document.getElementById('options');
    options.style.display = options.style.display === 'block' ? 'none' : 'block';
}

// Chama a verificação de login quando a página é carregada
window.onload = checkLogin;



//Lista de favorito

document.addEventListener('DOMContentLoaded', function() {
    fetch('/getFavorites')
        .then(response => response.json())
        .then(data => {
            const favoriteBooksDiv = document.getElementById('favoriteBooks');
            data.forEach(book => {
                const bookElement = document.createElement('div');
                bookElement.classList.add('livro');
                bookElement.innerHTML = `
                    <h2>${book.title}</h2>
                    <h4>${book.description}</h4>
                `;
                favoriteBooksDiv.appendChild(bookElement);
            });
        })
        .catch(error => {
            console.error('Error fetching favorite books:', error);
        });
});

