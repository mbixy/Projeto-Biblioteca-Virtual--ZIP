const fileInput = document.getElementById('file-input');
const fotoPerfil = document.getElementById('foto-perfil');

fileInput.addEventListener('change', function() {
    const file = fileInput.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
            fotoPerfil.src = e.target.result;
            fotoPerfil.style.display = 'block'; // Exibe a imagem
        };

        reader.readAsDataURL(file);
    }
});