const express = require('express');
const bodyParser = require('body-parser');
const { inserirUsuario, verificarUsuario } = require('./db'); // Importando a função
const cors = require('cors'); // Importando o CORS

const app = express();
app.use(cors()); // Habilitando o CORS
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Defina suas rotas aqui

app.post('/usuario', (req, res) => {
    const usuario = req.body;

    inserirUsuario(usuario, (erro, resultados) => {
        if (erro) {
            console.error(erro);
            return res.status(500).json({ message: 'Erro ao cadastrar usuário.' });
        }
        res.status(201).json({ message: 'Usuário cadastrado com sucesso!', id: resultados.insertId });
    });
});

// Rota para verificar usuário
app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    verificarUsuario(email, senha, (erro, resultados) => {
        if (erro) {
            console.error(erro);
            return res.status(500).json({ message: 'Erro ao verificar usuário.' });
        }
        if (resultados.length > 0) {
            res.status(200).json({ message: 'Usuário verificado com sucesso!' });
        } else {
            res.status(401).json({ message: 'E-mail ou senha incorretos.' });
        }
    });
});


const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
