document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const livros = document.querySelectorAll('.livro');
    livros.forEach(function(livro) {
        const titulo = livro.querySelector('.titulo').innerText.toLowerCase();
        const autor = livro.querySelector('.autor').innerText.toLowerCase();
        if (titulo.includes(searchInput) || autor.includes(searchInput)) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
});